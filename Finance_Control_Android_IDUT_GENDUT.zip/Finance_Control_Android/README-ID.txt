FINANCE CONTROL — PROJECT APK ANDROID

Ini adalah project Android Studio untuk membungkus Finance Control menjadi aplikasi Android offline.
Fitur HTML yang sudah ada dibawa ke WebView, termasuk localStorage, pencarian/filter, drag urutan, backup/restore, dan reset.

CARA BUILD APK:
1. Buka folder ini di Android Studio terbaru.
2. Tunggu Gradle Sync selesai dan izinkan Android Studio mengunduh Android SDK/Gradle yang diminta.
3. Pilih Build > Build APK(s).
4. APK debug biasanya muncul di:
   app/build/outputs/apk/debug/app-debug.apk

CATATAN:
- Project ini belum merupakan file APK jadi tidak bisa langsung dipasang.
- Lingkungan pembuatan saat ini tidak memiliki Android SDK/Gradle, sehingga APK tidak diklaim sudah ter-build.
- Backup dari Android disimpan ke folder Download sebagai JSON.
