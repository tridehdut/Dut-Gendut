package com.financecontrol.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.provider.MediaStore;
import android.webkit.*;
import android.view.*;
import java.io.*;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView web;
    private static final int PICK_FILE = 1001;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p){
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("application/json");
                startActivityForResult(i, PICK_FILE); pending = cb; return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        web.loadUrl("file:///android_asset/index.html");
    }
    private ValueCallback<Uri[]> pending;
    @Override protected void onActivityResult(int r,int c,Intent d){ super.onActivityResult(r,c,d); if(r==PICK_FILE && pending!=null){ pending.onReceiveValue(c==RESULT_OK&&d!=null?new Uri[]{d.getData()}:null); pending=null; } }

    public class Bridge {
        @JavascriptInterface public void saveBackup(String json){
            try {
                String name="Finance-Control-Backup-"+System.currentTimeMillis()+".json";
                ContentValues v=new ContentValues(); v.put(MediaStore.Downloads.DISPLAY_NAME,name); v.put(MediaStore.Downloads.MIME_TYPE,"application/json"); v.put(MediaStore.Downloads.RELATIVE_PATH,"Download");
                Uri u=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);
                if(u!=null){ try(OutputStream out=getContentResolver().openOutputStream(u)){ out.write(json.getBytes(StandardCharsets.UTF_8)); } }
                runOnUiThread(()->Toast.makeText(MainActivity.this,"Backup tersimpan di Download",Toast.LENGTH_LONG).show());
            }catch(Exception e){ runOnUiThread(()->Toast.makeText(MainActivity.this,"Gagal menyimpan backup",Toast.LENGTH_LONG).show()); }
        }
        @JavascriptInterface public void pickBackup(){ runOnUiThread(()->{ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("application/json"); startActivityForResult(i,PICK_FILE); }); }
    }
    @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
